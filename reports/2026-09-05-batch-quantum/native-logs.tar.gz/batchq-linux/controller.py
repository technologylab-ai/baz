from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import select
import shlex
import signal
import subprocess
import sys
import uuid

worktree = Path('/Users/rs/code/github.com/technologylab.ai/zig-http-batchq')
cache = worktree / '.zig-cache/batchq-linux'
commit = 'dbb639859e4c8503310933a2e53f0aaf45e2fca0'
remote_root = '/tmp/zig-http-compare.PIwh35'
token = uuid.uuid4().hex
receipt = dict(schema_version=1, commit=commit, started_utc=datetime.now(timezone.utc).isoformat(),
               root=remote_root, token=token, ok=False, timed_loads=False, commands=[])

holder_code = r'''
import json, os, re, socket, sys
from datetime import datetime,timezone
from pathlib import Path
lock=Path('/tmp/zig-http-measurement.lock')
token=sys.argv[1]
def scan():
    rows=[]
    for p in Path('/proc').glob('[0-9]*/cmdline'):
        try:
            if int(p.parent.name)==os.getpid(): continue
            cmd=p.read_bytes().replace(b'\0',b' ').decode('utf-8','replace').strip()
            if any(x in cmd for x in ('/bin/wrk','tools/compare.py','/bin/zig-http','zig build','benchmarks/prepare/prepare.py','mrhttp-build/launch.sh','tests/batch_integration.py','tests/gather_integration.py','tests/inline_integration.py','tools/smoke.py')):
                rows.append(dict(pid=int(p.parent.name),command=cmd))
        except (FileNotFoundError,PermissionError,ProcessLookupError): pass
    return rows
existing=scan()
if existing:
    print(json.dumps(dict(status='pending',processes=existing)),flush=True);sys.exit(75)
try: lock.mkdir()
except FileExistsError:
    print(json.dumps(dict(status='pending',owner=(lock/'owner.json').read_text() if (lock/'owner.json').exists() else 'incomplete metadata')),flush=True);sys.exit(75)
owner=dict(schema=1,token=token,host=socket.gethostname(),owner='Codex /root/tfb_linux_build',purpose='Exact dbb6398 batchq Linux publication gates and ReleaseSafe build; no timed load',created_utc=datetime.now(timezone.utc).isoformat(),owner_pid=os.getpid(),owner_start_ticks=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19],work_root='/tmp/zig-http-compare.PIwh35/batchq')
(lock/'owner.json').write_text(json.dumps(owner,indent=2)+'\n')
print(json.dumps(dict(status='acquired',owner=owner)),flush=True)
request=sys.stdin.readline().strip()
remaining=scan()
if request!='release' or remaining:
    print(json.dumps(dict(status='retained',request=request,processes=remaining)),flush=True);sys.exit(76)
actual=json.loads((lock/'owner.json').read_text())
assert actual['token']==token and actual['owner_pid']==os.getpid()
(lock/'owner.json').unlink();lock.rmdir()
print(json.dumps(dict(status='released',owned_processes_remaining=[],released_utc=datetime.now(timezone.utc).isoformat())),flush=True)
'''

def run(argv, logname, timeout=300, cwd=worktree, stdin=None):
    record=dict(argv=argv, timeout_seconds=timeout, log=logname)
    receipt['commands'].append(record)
    with (cache/logname).open('w') as out:
        p=subprocess.Popen(argv,cwd=cwd,stdin=stdin,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
        try:
            p.wait(timeout=timeout)
        except BaseException:
            try: os.killpg(p.pid,signal.SIGTERM)
            except ProcessLookupError: pass
            try: p.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
            raise
    record['returncode']=p.returncode
    if p.returncode: raise subprocess.CalledProcessError(p.returncode,argv)

assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=worktree,text=True).strip()==commit
assert not subprocess.check_output(['git','status','--porcelain'],cwd=worktree,text=True).strip()
holder=subprocess.Popen(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','omarx1',shlex.join(['python3','-u','-c',holder_code,token])],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
assert select.select([holder.stdout],[],[],20)[0], 'reservation acquisition watchdog'
initial=json.loads(holder.stdout.readline())
receipt['reservation']=initial
print(json.dumps(initial),flush=True)
if initial['status']!='acquired':
    holder.stdin.close();holder.wait(timeout=10)
    (cache/'batchq-controller-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    raise SystemExit(75)
try:
    run(['sh','tools/verify_linux_ssh.sh','omarx1'],'publication.log',1200)
    print('Maintained native publication gates passed.',flush=True)
    archive=cache/'batchq-source.tar'
    subprocess.run(['git','archive','--format=tar','--output='+str(archive),commit],cwd=worktree,check=True,timeout=60)
    receipt['source_archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest()
    setup="set -eu; test -d /tmp/zig-http-compare.PIwh35; test ! -L /tmp/zig-http-compare.PIwh35; test ! -e /tmp/zig-http-compare.PIwh35/batchq; mkdir /tmp/zig-http-compare.PIwh35/batchq; tar -xf - -C /tmp/zig-http-compare.PIwh35/batchq"
    with archive.open('rb') as stream:
        run(['ssh','omarx1',setup],'batchq-archive.log',60,stdin=stream)
    build="set -eu; cd /tmp/zig-http-compare.PIwh35/batchq; test \"$(zig version)\" = 0.16.0; test \"$(cat .zig-version)\" = 0.16.0; timeout 300 zig build -Doptimize=ReleaseSafe -j2 --summary all; sha256sum zig-out/bin/zig-http /home/rs/.local/share/mise/installs/zig/0.16.0/zig; zig env; powerprofilesctl get"
    run(['ssh','omarx1',build],'batchq-build.log',320)
    print('Retained batchq ReleaseSafe binary built.',flush=True)
    receipt['ok']=True
except BaseException as error:
    receipt['error']=type(error).__name__+': '+str(error)
    raise
finally:
    holder.stdin.write('release\n');holder.stdin.flush()
    assert select.select([holder.stdout],[],[],30)[0], 'reservation release watchdog'
    result=json.loads(holder.stdout.readline());receipt['release']=result
    print(json.dumps(result),flush=True)
    holder.stdin.close();holder.wait(timeout=10)
    receipt['finished_utc']=datetime.now(timezone.utc).isoformat()
    (cache/'batchq-controller-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    assert result['status']=='released', 'reservation retained; inspect owned workload state'
