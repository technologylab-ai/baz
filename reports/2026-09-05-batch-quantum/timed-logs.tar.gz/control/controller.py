import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import uuid

root = Path('/tmp/zig-http-compare.PIwh35')
lock = Path('/tmp/zig-http-measurement.lock')
wait_started = time.monotonic()
while True:
    try:
        lock.mkdir(mode=0o700)
        break
    except FileExistsError:
        waited = time.monotonic() - wait_started
        if waited >= 600:
            raise TimeoutError('No host reservation became available in 600s; no timed load started')
        if int(waited) % 30 == 0:
            print(json.dumps(dict(waiting_for_lock=True, waited_seconds=round(waited))), flush=True)
        time.sleep(1)
owner = dict(schema=1, token=uuid.uuid4().hex, host=os.uname().nodename,
             owner='Codex /root batch/callback matrix', owner_pid=os.getpid(),
             owner_start_ticks=Path(f'/proc/{os.getpid()}/stat').read_text().rsplit(')', 1)[1].split()[19],
             purpose='Same-binary ReleaseSafe B16/B64 x Q64/Q256,128 clients,depth16/128; no overlapping load',
             work_root=str(root), created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(lock / 'owner.json').write_text(json.dumps(owner, indent=2) + '\n')
(root / 'batchq-matrix-lock.json').write_text(json.dumps(owner, indent=2) + '\n')
print(json.dumps(owner), flush=True)
receipt = dict(owner=owner, waited_seconds=time.monotonic() - wait_started, commands=[], ok=False)
launched = False
hashes = json.loads((root / 'batchq-matrix-hashes.json').read_text())

try:
    # A legacy workload may predate lock adoption. Check after acquisition too,
    # before creating any workload of our own; do not stop another agent's work.
    competing = []
    for path in Path('/proc').glob('[0-9]*'):
        try:
            args = [v.decode(errors='replace') for v in (path / 'cmdline').read_bytes().split(b'\0') if v]
            names = [Path(v).name for v in args[:2]]
            if any(v in ('wrk', 'wrk2', 'zig-http', 'libreactor', 'mrhttp', 'compare.py', 'remote_sweep.sh') for v in names) or (names and names[0] == 'zig' and args[1:2] == ['build']):
                competing.append(int(path.name))
        except OSError:
            pass
    receipt['preexisting_workloads'] = competing
    assert not competing, f'Another workload predates our reservation: {competing}'
    for path, expected in hashes.items():
        assert hashlib.sha256((root / path).read_bytes()).hexdigest() == expected
    command = ['python3', 'tools/compare.py', str(root / 'batchq-matrix-config.json'),
               '--output', str(root / 'batchq-matrix'), '--connections', '128',
               '--pipelines', '16', '128', '--seconds', '5', '--repeats', '3',
               '--threads', '4', '--seed', '20260905']
    launched = True
    process = subprocess.Popen(command, cwd=root / 'batchq', start_new_session=True)
    try:
        result = process.wait(timeout=600)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGTERM)
        try: process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL);process.wait(timeout=5)
        raise
    receipt['commands'].append(dict(argv=command, exit=result))
    assert result == 0
    trials = json.loads((root / 'batchq-matrix/results.json').read_text())['trials']
    assert len(trials) == 24
    for trial in trials:
        batch, budget = [int(v[1:]) for v in trial['server'].split('-')]
        stats = trial['stats']
        assert stats['response_batch_limit'] == batch
        assert stats['inline_callback_budget'] == budget
        assert stats['max_batch_responses'] <= batch
        assert stats['max_inline_callbacks_per_turn'] <= budget
        assert stats['rejected'] == stats['timeouts'] == 0
    receipt['ok'] = True
finally:
    receipt['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    # Keep a failed/interrupted reservation if any child still owns this root.
    ancestors = set()
    pid = os.getpid()
    while pid > 1:
        ancestors.add(pid)
        pid = int(Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()[1])
    active = []
    for path in Path('/proc').glob('[0-9]*'):
        if int(path.name) in ancestors:
            continue
        try:
            if any((v := str((path / name).resolve(strict=True))) == str(root)
                   or v.startswith(str(root) + '/') for name in ('cwd', 'exe')):
                active.append(int(path.name))
        except (OSError, RuntimeError):
            pass
    receipt['remaining_owned_processes'] = active if launched else []
    receipt['binary_sha256'] = hashes
    if not active or not launched:
        assert json.loads((lock / 'owner.json').read_text())['token'] == owner['token']
        (lock / 'owner.json').unlink()
        lock.rmdir()
        receipt['lock_released'] = True
    else:
        receipt['lock_released'] = False
    (root / 'batchq-matrix-controller.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(dict(controller_ok=receipt['ok'], lock_released=receipt['lock_released'],
                          remaining_owned_processes=active)), flush=True)
