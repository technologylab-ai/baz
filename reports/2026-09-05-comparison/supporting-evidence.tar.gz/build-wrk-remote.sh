#!/bin/bash
set -euxo pipefail
task_root=/tmp/zig-http-compare.qHiBFl
test -d "$task_root/wrk-build/wrk"
cd "$task_root/wrk-build/wrk"
date -u
uname -a
gcc --version
openssl version
pacman -Q openssl glibc gcc
git rev-parse HEAD
git archive HEAD | sha256sum
sha256sum deps/*
make -j2 WITH_OPENSSL=/usr
cp wrk "$task_root/bin/wrk"
sha256sum wrk /usr/lib/libssl.so.3 /usr/lib/libcrypto.so.3
ldd wrk
./wrk --version || test "$?" = 1
