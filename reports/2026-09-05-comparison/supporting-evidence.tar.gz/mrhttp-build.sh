#!/bin/sh
set -eu
python3 -m pip download --dest /work/packages -r /work/requirements.txt
cd /work/packages
sha256sum * > /work/packages.sha256
python3 -m venv /work/venv
/work/venv/bin/pip install --no-index --find-links=/work/packages -r /work/requirements.txt
/work/venv/bin/python -m pip freeze > /work/pip-freeze.txt
/work/venv/bin/python --version > /work/python-version.txt
cc --version > /work/cc-version.txt
cat /etc/os-release > /work/os-release.txt
