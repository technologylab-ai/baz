#!/bin/sh
set -eu
exec docker run --rm --name zig-http-tfb-mrhttp --cpuset-cpus 0-2 --network host -v /tmp/zig-http-compare.qHiBFl/mrhttp-build:/work -w /work python@sha256:53cb5152064a7e7b485ad42704ea63c5155b264c82e7f17de99d3aa28e4f8956 /work/venv/bin/python -u /work/app.py
