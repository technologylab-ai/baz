#!/bin/bash
set -euxo pipefail
task_root=/tmp/zig-http-compare.qHiBFl
test -d "$task_root/libreactor-build"
cd "$task_root/libreactor-build"
prefix="$PWD/prefix"
export CC=gcc AR=gcc-ar NM=gcc-nm RANLIB=gcc-ranlib
export CPPFLAGS="-I$prefix/include"
export LDFLAGS="-L$prefix/lib"
date -u
uname -a
gcc --version
for project in libdynamic libclo libreactor; do
  git -C "$project" rev-parse HEAD
  git -C "$project" archive HEAD | sha256sum
done
sha256sum app/Makefile app/libreactor.dockerfile app/src/*
cd libdynamic
./autogen.sh
./configure --prefix="$prefix"
make -j2
make install
cd ../libclo
sed -i '/#include <dynamic.h>/d' src/clo.c
./autogen.sh
./configure --prefix="$prefix" CFLAGS="-march=native"
make -j2
make install
git diff
cd ../libreactor
./autogen.sh
./configure --prefix="$prefix"
make -j2
make install
cd ../app
cp src/libreactor.c src/libreactor.c.upstream
sed -i 's/server_open(&s, 0, 8080);/server_open(\&s, 0x7f000001, 8080);/' src/libreactor.c
diff -u src/libreactor.c.upstream src/libreactor.c || test "$?" = 1
make -j2 libreactor LDADD="-L$prefix/lib -lreactor -ldynamic -lclo"
cp libreactor "$task_root/bin/libreactor"
sha256sum src/libreactor.c libreactor
ldd libreactor
