
import multiprocessing
import mrhttp
import mrjson as json

app = mrhttp.Application()

@app.route('/json', _type="json")
def j(r):
  return json.dumps({'message': 'Hello, world!'})

@app.route('/plaintext', _type="text", options=['cache'])
def p(r):
  return "Hello, world!"


app.run('127.0.0.1', 8080, cores=3)

