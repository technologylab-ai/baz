import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import uuid

root = Path('/tmp/zig-http-compare.PIwh35')
lock = Path('/tmp/zig-http-measurement.lock')
wait_started = time.monotonic()
while True:
    try:
        lock.mkdir(mode=0o700)
        break
    except FileExistsError:
        waited = time.monotonic() - wait_started
        if waited >= 600:
            raise TimeoutError('No host reservation became available in 600s; no timed load started')
        if int(waited) % 30 == 0:
            print(json.dumps(dict(waiting_for_lock=True, waited_seconds=round(waited))), flush=True)
        time.sleep(1)
owner = dict(schema=1, token=uuid.uuid4().hex, host=os.uname().nodename,
             owner='Codex /root operation-cell ABBA', owner_pid=os.getpid(),
             owner_start_ticks=Path(f'/proc/{os.getpid()}/stat').read_text().rsplit(')', 1)[1].split()[19],
             purpose='Baseline/candidate ReleaseSafe ABBA, capacities128/1024, client depths1/16/128; no competing builds or measurements',
             work_root=str(root), created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(lock / 'owner.json').write_text(json.dumps(owner, indent=2) + '\n')
(root / 'opcells-abba-lock.json').write_text(json.dumps(owner, indent=2) + '\n')
print(json.dumps(owner), flush=True)
receipt = dict(owner=owner, waited_seconds=time.monotonic() - wait_started, commands=[], ok=False)
launched = False
hashes = {
    'zig-http/zig-out/bin/zig-http': '860764caee352c76ec4be68fa2588a58c89dd60a8982acf0ecc394fef65cd102',
    'candidate/zig-out/bin/zig-http': 'a2e125146cb655a882580f02ee7c04a94ab98f76de01551f66457e05e31d799e',
    'bin/wrk': 'c8000cec3cb25e87292c983828ecfcfd4108ce39d2bb01b9cd313f17dcf290af',
}
try:
    # A legacy workload may predate lock adoption. Check after acquisition too,
    # before creating any workload of our own; do not stop another agent's work.
    competing = []
    for path in Path('/proc').glob('[0-9]*'):
        try:
            args = [v.decode(errors='replace') for v in (path / 'cmdline').read_bytes().split(b'\0') if v]
            names = [Path(v).name for v in args[:2]]
            if any(v in ('wrk', 'wrk2', 'zig-http', 'libreactor', 'mrhttp', 'compare.py', 'remote_sweep.sh') for v in names) or (names and names[0] == 'zig' and args[1:2] == ['build']):
                competing.append(int(path.name))
        except OSError:
            pass
    receipt['preexisting_workloads'] = competing
    assert not competing, f'Another workload predates our reservation: {competing}'
    for capacity in (128, 1024):
        for path, expected in hashes.items():
            assert hashlib.sha256((root / path).read_bytes()).hexdigest() == expected
        command = ['python3', 'tools/compare.py', str(root / f'opcells-config-{capacity}.json'),
                   '--output', str(root / f'opcells-abba-{capacity}'), '--connections', '128',
                   '--pipelines', '1', '16', '128', '--seconds', '5', '--repeats', '2',
                   '--threads', '4', '--seed', '20260905', '--order', 'abba']
        launched = True
        process = subprocess.Popen(command, cwd=root / 'candidate', start_new_session=True)
        try:
            result = process.wait(timeout=600)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=15)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=5)
            raise
        receipt['commands'].append(dict(argv=command, exit=result))
        assert result == 0
    receipt['ok'] = True
finally:
    receipt['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    # Keep a failed/interrupted reservation if any child still owns this root.
    ancestors = set()
    pid = os.getpid()
    while pid > 1:
        ancestors.add(pid)
        pid = int(Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()[1])
    active = []
    for path in Path('/proc').glob('[0-9]*'):
        if int(path.name) in ancestors:
            continue
        try:
            if any((v := str((path / name).resolve(strict=True))) == str(root)
                   or v.startswith(str(root) + '/') for name in ('cwd', 'exe')):
                active.append(int(path.name))
        except (OSError, RuntimeError):
            pass
    receipt['remaining_owned_processes'] = active if launched else []
    receipt['binary_sha256'] = hashes
    if not active or not launched:
        assert json.loads((lock / 'owner.json').read_text())['token'] == owner['token']
        (lock / 'owner.json').unlink()
        lock.rmdir()
        receipt['lock_released'] = True
    else:
        receipt['lock_released'] = False
    (root / 'opcells-abba-controller.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(dict(controller_ok=receipt['ok'], lock_released=receipt['lock_released'],
                          remaining_owned_processes=active)), flush=True)
