const std = @import("std");
const build_facilio = @import("deps/zap/facil.io/build.zig").build_facilio;

pub fn build(b: *std.Build) !void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    if (optimize != .ReleaseSafe) @panic("basic comparison requires ReleaseSafe");
    const framework_root = b.option([]const u8, "framework-root", "Absolute frozen zig-http source directory") orelse @panic("-Dframework-root is required");
    const web = b.createModule(.{
        .root_source_file = .{ .cwd_relative = b.pathJoin(&.{ framework_root, "src/web.zig" }) },
        .target = target,
        .optimize = optimize,
        .link_libc = true,
    });
    const support = b.createModule(.{
        .root_source_file = .{ .cwd_relative = b.pathJoin(&.{ framework_root, "examples/support.zig" }) },
        .target = target,
        .optimize = optimize,
        .imports = &.{.{ .name = "http_app", .module = web }},
    });
    const facilio = try build_facilio("deps/zap/facil.io", b, target, optimize, false);
    const zap = b.createModule(.{
        .root_source_file = b.path("deps/zap/src/zap.zig"),
        .target = target,
        .optimize = optimize,
    });
    zap.linkLibrary(facilio);
    const verify = b.step("verify", "Compile and install both exact comparison fixtures");
    inline for (.{ "app", "zap" }) |name| {
        const module = b.createModule(.{
            .root_source_file = b.path("src/" ++ name ++ ".zig"),
            .target = target,
            .optimize = optimize,
            .link_libc = true,
        });
        if (comptime std.mem.eql(u8, name, "app")) {
            module.addImport("http_app", web);
            module.addImport("example_support", support);
        } else module.addImport("zap", zap);
        const executable = b.addExecutable(.{ .name = "basic-" ++ name, .root_module = module });
        const install = b.addInstallArtifact(executable, .{});
        verify.dependOn(&install.step);
        b.getInstallStep().dependOn(&install.step);
    }
}
