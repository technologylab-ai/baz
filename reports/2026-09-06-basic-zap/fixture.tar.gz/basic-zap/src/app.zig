const std = @import("std");
const web = @import("http_app");
const support = @import("example_support");
const Shared = struct {};
const Application = web.App(Shared);

fn plaintext(ctx: *Application.Context) !void {
    try ctx.response.bytes(200, "text/plain", "Hello, World!");
}

pub fn main(init: std.process.Init) !void {
    var shared: Shared = .{};
    var config = try support.config(init);
    config.execution = .inline_event_loop;
    config.workers = 0;
    config.shards = 1;
    config.connections = 128;
    const app = try Application.init(.{ .allocator = init.gpa, .io = init.io, .shared = &shared, .server = config });
    defer app.deinit();
    try app.route("GET", "/plaintext", plaintext);
    try support.run(app, init);
}
