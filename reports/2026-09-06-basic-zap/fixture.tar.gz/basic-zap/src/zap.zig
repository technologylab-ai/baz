const std = @import("std");
const zap = @import("zap");

fn plaintext(request: zap.Request) !void {
    try request.setContentType(.TEXT);
    if (!std.mem.eql(u8, request.path orelse "", "/plaintext")) {
        request.setStatusNumeric(404);
        return request.sendBody("Not Found");
    }
    if (!std.mem.eql(u8, request.method orelse "", "GET")) {
        request.setStatusNumeric(405);
        return request.sendBody("Method Not Allowed");
    }
    return request.sendBody("Hello, World!");
}

pub fn main(init: std.process.Init) !void {
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, init.gpa);
    defer args.deinit();
    _ = args.next();
    var port: u16 = 8080;
    while (args.next()) |flag| {
        if (!std.mem.eql(u8, flag, "--port")) return error.InvalidArgument;
        port = try std.fmt.parseInt(u16, args.next() orelse return error.MissingArgument, 10);
    }
    var listener = zap.HttpListener.init(.{
        .port = port,
        .interface = "127.0.0.1",
        .on_request = plaintext,
        .max_clients = 128,
        .log = false,
    });
    try listener.listen();
    std.debug.print("READY port={d} backend=facil.io threads=1 workers=1 optimize={s}\n", .{ port, @tagName(@import("builtin").mode) });
    zap.start(.{ .threads = 1, .workers = 1 });
}
