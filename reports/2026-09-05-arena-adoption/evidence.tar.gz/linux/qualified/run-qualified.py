from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess

candidate = Path('/tmp/zig-http-compare.PIwh35/arena-integration-bbcec8a')
output = candidate / '.zig-cache/qualified'
identity = json.loads((output / 'identity.json').read_text())
receipt = dict(started_utc=datetime.now(timezone.utc).isoformat(), ok=False, commands=[], validations=[])

try:
    for cpus in (1, 3):
        for path, expected in identity['binaries'].items():
            assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected, path
        command = ['python3', 'tools/compare.py', str(output / f'configuration-{cpus}cpu.json'),
                   '--output', str(output / f'{cpus}cpu'), '--connections', '128',
                   '--pipelines', '1', '16', '128', '--seconds', '5', '--repeats', '3',
                   '--threads', '4', '--seed', '20260905']
        record = dict(argv=command, started_utc=datetime.now(timezone.utc).isoformat())
        receipt['commands'].append(record)
        with (output / f'{cpus}cpu-console.log').open('w') as log:
            process = subprocess.Popen(command, cwd=candidate, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = process.wait(timeout=1200)
            except BaseException:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=5)
                raise
        record.update(returncode=code, finished_utc=datetime.now(timezone.utc).isoformat())
        assert code == 0, f'{cpus}cpu harness failed'
        results = json.loads((output / f'{cpus}cpu/results.json').read_text())
        assert results['ok'] and len(results['trials']) == 18
        assert results['ordering'] == 'shuffled' and results['repeats'] == 3
        for trial in results['trials']:
            assert trial['warmup']['ok'] and trial['result']['ok']
            assert trial['power_before']['profile'] == trial['power_after']['profile'] == 'performance'
            if trial['server'] != 'zig-http':
                continue
            stats = trial['stats']
            assert stats['shards'] == cpus
            assert stats['response_batch_limit'] == 128 and stats['callbacks_per_turn'] == 8192
            assert stats['max_batch_responses'] <= 128 and stats['max_inline_callbacks_per_turn'] <= 8192
            assert stats['peak_connections'] <= 128 and stats['gather_send']
            for field in ('allocation_calls_after_start', 'live_connections', 'live_operations', 'rejected', 'timeouts', 'workers', 'worker_dispatches', 'prearmed_receives'):
                assert stats[field] == 0, (cpus, trial['index'], field, stats[field])
            if cpus > 1:
                assert any(line.startswith('SHARDS ') for line in trial['server_log'].splitlines())
        receipt['validations'].append(dict(cpus=cpus, trials=18, zig_trials=9, ok=True))
        print(json.dumps(receipt['validations'][-1]), flush=True)
    receipt['ok'] = True
except BaseException as error:
    receipt['error'] = type(error).__name__ + ': ' + str(error)
    raise
finally:
    receipt['finished_utc'] = datetime.now(timezone.utc).isoformat()
    (output / 'timing-controller.json').write_text(json.dumps(receipt, indent=2) + '\n')
