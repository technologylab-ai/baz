
import json,os
from pathlib import Path
from datetime import datetime,timezone
lock=Path('/tmp/zig-http-measurement.lock')
owner=json.loads((lock/'owner.json').read_text())
assert owner['token']=='a115ee6a94c04c1aa22603f4168d6690'
assert owner['owner_pid']==1069234 and owner['owner_start_ticks']=='48463952'
old=Path('/proc/1069234/stat')
old_stat=old.read_text() if old.exists() else None
assert old_stat is None,'original keeper still exists; preserve reservation'
ancestors=set();pid=os.getpid()
while pid>1:
 ancestors.add(pid)
 try:pid=int(Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[1])
 except FileNotFoundError:break
active=[]
for path in Path('/proc').glob('[0-9]*'):
 if int(path.name) in ancestors:continue
 try:
  args=[a.decode(errors='replace') for a in (path/'cmdline').read_bytes().split(b'\0') if a]
  names=[Path(a).name for a in args[:2]]
  if any(a in ('wrk','wrk2','zig-http','libreactor','mrhttp','compare.py','run-qualified.py','remote_sweep.sh') for a in names) or (names and names[0]=='zig' and args[1:2]==['build']):active.append(dict(pid=int(path.name),args=args))
 except OSError:pass
assert not active,active
(lock/'owner.json').unlink();lock.rmdir()
print(json.dumps(dict(status='released',recovery=True,owner=owner,original_keeper_absent=True,original_keeper_expected_start_ticks='48463952',owned_processes_remaining=active,released_utc=datetime.now(timezone.utc).isoformat()),indent=2))
