from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import select
import shlex
import signal
import subprocess
import sys
import uuid

worktree = Path('/Users/rs/code/github.com/technologylab.ai/zig-http-arena-integration')
cache = worktree / '.zig-cache/arena-qualified-linux'
commit = 'bbcec8aa9516efc470238b9edeea4f01b1f4a6d7'
remote_root = '/tmp/zig-http-compare.PIwh35/arena-integration-bbcec8a'
token = uuid.uuid4().hex
receipt = dict(schema_version=1, commit=commit, started_utc=datetime.now(timezone.utc).isoformat(),
               root=remote_root, token=token, ok=False, timed_loads=False, commands=[])

holder_code = r'''
import json, os, re, socket, sys
from datetime import datetime,timezone
from pathlib import Path
lock=Path('/tmp/zig-http-measurement.lock')
token=sys.argv[1]
def scan():
    rows=[]
    for p in Path('/proc').glob('[0-9]*/cmdline'):
        try:
            if int(p.parent.name)==os.getpid(): continue
            cmd=p.read_bytes().replace(b'\0',b' ').decode('utf-8','replace').strip()
            if any(x in cmd for x in ('/bin/wrk','tools/compare.py','/bin/zig-http','zig build','benchmarks/prepare/prepare.py','mrhttp-build/launch.sh','/bin/libreactor','remote_sweep.sh','tests/arena_lifecycle_integration.py','tests/integration.py','tests/batch_integration.py','tests/gather_integration.py','tests/inline_integration.py','tools/smoke.py')):
                rows.append(dict(pid=int(p.parent.name),command=cmd))
        except (FileNotFoundError,PermissionError,ProcessLookupError): pass
    return rows
existing=scan()
if existing:
    print(json.dumps(dict(status='pending',processes=existing)),flush=True);sys.exit(75)
try: lock.mkdir()
except FileExistsError:
    print(json.dumps(dict(status='pending',owner=(lock/'owner.json').read_text() if (lock/'owner.json').exists() else 'incomplete metadata')),flush=True);sys.exit(75)
owner=dict(schema=1,token=token,host=socket.gethostname(),owner='Codex /root/arena_parser_review',purpose='Exact bbcec8a publication gates then qualified ReleaseSafe comparison, 36 shuffled trials, one/three server CPUs; no overlapping builds during times',created_utc=datetime.now(timezone.utc).isoformat(),owner_pid=os.getpid(),owner_start_ticks=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19],work_root='/tmp/zig-http-compare.PIwh35/arena-integration-bbcec8a')
(lock/'owner.json').write_text(json.dumps(owner,indent=2)+'\n')
print(json.dumps(dict(status='acquired',owner=owner)),flush=True)
request=sys.stdin.readline().strip()
remaining=scan()
if request!='release' or remaining:
    print(json.dumps(dict(status='retained',request=request,processes=remaining)),flush=True);sys.exit(76)
actual=json.loads((lock/'owner.json').read_text())
assert actual['token']==token and actual['owner_pid']==os.getpid()
(lock/'owner.json').unlink();lock.rmdir()
print(json.dumps(dict(status='released',owned_processes_remaining=[],released_utc=datetime.now(timezone.utc).isoformat())),flush=True)
'''

def run(argv, logname, timeout=300, cwd=worktree, stdin=None):
    record=dict(argv=argv, timeout_seconds=timeout, log=logname)
    receipt['commands'].append(record)
    with (cache/logname).open('w') as out:
        p=subprocess.Popen(argv,cwd=cwd,stdin=stdin,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
        try:
            p.wait(timeout=timeout)
        except BaseException:
            try: os.killpg(p.pid,signal.SIGTERM)
            except ProcessLookupError: pass
            try: p.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
            raise
    record['returncode']=p.returncode
    if p.returncode: raise subprocess.CalledProcessError(p.returncode,argv)



assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=worktree,text=True).strip()==commit
receipt['input_status']=subprocess.check_output(['git','status','--porcelain'],cwd=worktree,text=True)
assert not receipt['input_status'].strip()
receipt['publication_gate']=True
receipt['source_archive_sha256']=hashlib.sha256((cache/'source.tar').read_bytes()).hexdigest()
holder=subprocess.Popen(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','omarx1',shlex.join(['python3','-u','-c',holder_code,token])],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
assert select.select([holder.stdout],[],[],20)[0], 'reservation acquisition watchdog'
line=holder.stdout.readline()
if not line: raise RuntimeError(holder.stderr.read())
initial=json.loads(line)
receipt['reservation']=initial
print(json.dumps(initial),flush=True)
(cache/'lock.json').write_text(json.dumps(initial,indent=2)+'\n')
if initial['status']!='acquired':
    holder.stdin.close();holder.wait(timeout=10)
    (cache/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    raise SystemExit(75)
remote_created=False
try:
    run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','omarx1','uname -a; lscpu; zig version; zig env; powerprofilesctl get; cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor /sys/devices/system/cpu/cpu0/cpufreq/energy_performance_preference'], 'environment.log',60)
    run(['sh','tools/verify_linux_ssh.sh','omarx1'],'publication-gates.log',1200)
    print('Clean pushed bbcec8a Linux native gates passed; exact local archive already captured; parent may edit documentation.',flush=True)
    (cache/'input-captured.json').write_text(json.dumps(dict(commit=commit,source_archive_sha256=receipt['source_archive_sha256'],publication_gates_passed=True,captured_utc=datetime.now(timezone.utc).isoformat()),indent=2)+'\n')
    setup='set -eu; test -d /tmp/zig-http-compare.PIwh35; test ! -L /tmp/zig-http-compare.PIwh35; test ! -e '+remote_root+'; test ! -L '+remote_root+'; mkdir '+remote_root+'; mkdir -p '+remote_root+'/.zig-cache/qualified; cat > '+remote_root+'/.zig-cache/qualified/source.tar; tar -xf '+remote_root+'/.zig-cache/qualified/source.tar -C '+remote_root
    with (cache/'source.tar').open('rb') as stream:
        run(['ssh','omarx1',setup],'archive-transfer.log',60,stdin=stream)
    remote_created=True
    for name in ['configuration-1cpu.json','configuration-3cpu.json','preparation-reference.json','run-qualified.py']:
        with (cache/name).open('rb') as stream:
            run(['ssh','omarx1','cat > '+remote_root+'/.zig-cache/qualified/'+name],name+'.transfer.log',30,stdin=stream)
    run(['ssh','omarx1','set -eu; cd '+remote_root+'; test "$(zig version)" = 0.16.0; test "$(cat .zig-version)" = 0.16.0; timeout 300 zig build -Doptimize=ReleaseSafe -j2 --summary all'],'candidate-build.log',330)
    identity_code="""from pathlib import Path
import hashlib,json,subprocess
root=Path('/tmp/zig-http-compare.PIwh35/arena-integration-bbcec8a')
out=root/'.zig-cache/qualified'
reference=json.loads((out/'preparation-reference.json').read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(out/'source.tar')==reference['source_archive_sha256']
binaries={str(root/'zig-out/bin/zig-http'):sha(root/'zig-out/bin/zig-http')}
for path,expected in reference['binaries'].items():
 p=Path('/tmp/zig-http-compare.PIwh35')/path
 assert sha(p)==expected,(str(p),sha(p),expected)
 binaries[str(p)]=expected
compiler=Path('/home/rs/.local/share/mise/installs/zig/0.16.0/zig')
identity=dict(commit='bbcec8aa9516efc470238b9edeea4f01b1f4a6d7',binaries=binaries,compiler=str(compiler),compiler_sha256=sha(compiler),source_archive_sha256=reference['source_archive_sha256'],pins=reference['pins'],all_builds_finished_before_timings=True)
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\\n')
print(json.dumps(identity,indent=2))
"""
    run(['ssh','omarx1',shlex.join(['python3','-c',identity_code])],'identity.json',30)
    print('Exact candidate built and binary/compiler/pinned contender hashes validated; 36 timed trials starting.',flush=True)
    receipt['timed_loads']=True
    run(['ssh','omarx1','python3 '+remote_root+'/.zig-cache/qualified/run-qualified.py'],'timing-console.log',2450)
    receipt['ok']=True
except BaseException as error:
    receipt['error']=type(error).__name__+': '+str(error)
    raise
finally:
    if remote_created:
        with (cache/'raw-remote.tar.gz').open('wb') as stream:
            fetched=subprocess.run(['ssh','omarx1','tar -czf - --exclude=source.tar -C '+remote_root+'/.zig-cache qualified'],stdout=stream,stderr=subprocess.PIPE,timeout=60)
        receipt['artifacts_fetch_returncode']=fetched.returncode
        if fetched.returncode==0:
            import tarfile
            with tarfile.open(cache/'raw-remote.tar.gz') as archive: archive.extractall(cache,filter='data')
    holder.stdin.write('release\n');holder.stdin.flush()
    assert select.select([holder.stdout],[],[],30)[0], 'reservation release watchdog'
    result=json.loads(holder.stdout.readline());receipt['release']=result
    print(json.dumps(result),flush=True)
    holder.stdin.close();holder.wait(timeout=10)
    receipt['finished_utc']=datetime.now(timezone.utc).isoformat()
    (cache/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    assert result['status']=='released', 'reservation retained; inspect owned workload state'
